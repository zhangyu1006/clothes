from __future__ import print_function, division
import argparse
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torchvision
from torchvision import datasets,transforms
import os
import yaml
from model import resnet50


######################################################################
# Options
# --------

parser = argparse.ArgumentParser(description='Training')
parser.add_argument('--gpu_ids',default='0', type=str,help='gpu_ids: e.g. 0  0,1,2  0,2')
parser.add_argument('--which_epoch',default='last', type=str, help='0,1,2,3...or last')
parser.add_argument('--test_dir',default='F:/dataset/data-clothes/clothes-data',type=str, help='./test_data')
parser.add_argument('--name', default='ft_ResNet50', type=str, help='save model path')
parser.add_argument('--batchsize', default=8, type=int, help='batchsize')
parser.add_argument('--multi', action='store_true', help='use multiple query' )


opt = parser.parse_args()
###load config###
# load the training config
config_path = os.path.join('./model',opt.name,'opts.yaml')
with open(config_path, 'r') as stream:
        config = yaml.load(stream)
opt.stride = config['stride']

if 'nclasses' in config: # to compatible with old config files
    opt.nclasses = config['nclasses']
else: 
    opt.nclasses = 2 

str_ids = opt.gpu_ids.split(',')
#which_epoch = opt.which_epoch
name = opt.name
test_dir = opt.test_dir

gpu_ids = []
for str_id in str_ids:
    id = int(str_id)
    if id >=0:
        gpu_ids.append(id)


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("device", device)

# =============================================================================
# # set gpu ids
# if len(gpu_ids)>0:
#     torch.cuda.set_device(gpu_ids[0])
#     cudnn.benchmark = True
# =============================================================================

######################################################################
# Load Data
# ---------
#
# We will use torchvision and torch.utils.data packages for loading the
# data.
#
data_transforms = transforms.Compose([
        transforms.Resize((224,224), interpolation=3),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

data_dir = test_dir

image_datasets= datasets.ImageFolder(os.path.join(data_dir, 'test'),
                                          data_transforms)

dataloaders = torch.utils.data.DataLoader(image_datasets,opt.batchsize,
                                                 shuffle=False, num_workers=0)
class_names = image_datasets.classes


######################################################################
# Load model
#---------------------------
def load_network(network):
    save_path = os.path.join('./model',name,'net_%s.pth'%opt.which_epoch)
    network.load_state_dict(torch.load(save_path))
    return network


######################################################################
# Extract feature
# ----------------------
#
# Extract feature from  a trained model.correct = 0
print('-------test-----------')
model_structure = resnet50(opt.nclasses)
model = load_network(model_structure)

correct = 0
total = 0
with torch.no_grad():
    count = 0
    for data in dataloaders:
        inputs, labels = data
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
        count += 1
        if count%100 == 0:
            print(count)

print('Accuracy of the network on the test images: %d %%' % (
100 * correct / total))

class_correct = list(0. for i in range(10))
class_total = list(0. for i in range(10))
with torch.no_grad():
    for data in dataloaders:
        images, labels = data
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        _, predicted = torch.max(outputs, 1)
        c = (predicted == labels).squeeze()
        #print(predicted, labels, c)
        for i in range(labels.size(0)):
            label = labels[i]
            try:
                class_correct[label] += c[i].item()
            except:
                class_correct[label] += int(c)
            class_total[label] += 1
for i in range(len(class_names)):
    print('Accuracy of %5s : %2d %%' % (
        class_names[i], 100 * class_correct[i] / class_total[i]))