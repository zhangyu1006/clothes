import os
#需要先pip一下自然排序的包
import natsort as nt
import shutil

'''
将分好类，重命名完成的文件，复制到一个父文件夹，作为分类的总类别使用
'''

dir = r'F:/dataset/tee'
# 一个类的目标文件夹
target_dir = 'F:/dataset/tee_all/'
#target_dir = 'D:/pycharmcode/data/img/Jeans_all2one'

# 若目标文件夹不存在，则进行创建
if not os.path.exists(target_dir):
    os.makedirs(target_dir)

folders = nt.natsorted(os.listdir(dir))
folder_length = len(folders)
print("folder_length:", folder_length)

folder_num = 0
for folder in folders:
    print("folder:",folder)
    folder_dir = os.path.join(dir,folder)
    
    imgs = nt.natsorted(os.listdir(folder_dir))
    for img in imgs:
        img_path = os.path.join(folder_dir, img)
#        print(img_path)
        shutil.copy(img_path, target_dir)










